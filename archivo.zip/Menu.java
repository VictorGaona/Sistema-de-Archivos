package archivo;
import  java.util.*;
import  javax.swing.JOptionPane;

public class Menu {
	
       public static void main(String[]args){
	          
    	      Scanner in=new Scanner(System.in);
	          
    	      int n;
	
	          Metodos m=new Metodos();
	
	   do {
		   
		//n=Integer.parseInt(JOptionPane.showInputDialog("1.Registrar alumno\n2.Consulta general\n3.Busqueda\n4.Modificaciones\n5.Eliminar\n6.Destruir\n7.salir"));
		
		   System.out.println("_________MENU PRINCIPAL________");
		   System.out.println("(1) REGISTRO DE ALUMNO");
		   System.out.println("(2) CONSULTA GENERAL");
		   System.out.println("(3) BUSQUEDA");
		   System.out.println("(4) MODIFICAR");
		   System.out.println("(5) ELIMINAR");
		   System.out.println("(6) DESTRUIR");
		   System.out.println("(7) SALIR");
		   n=in.nextInt();
		   
	       switch(n){
	       
	       case 1:
                  m.registrar(); 
	              break;
	              
	       case 2:
	    	      m.consulta(); 
	    	      break;
	    	      
	       case 3:
	    	   
	    	      System.out.println("_____OPCIONES DE CONSULTA______");
	    	      System.out.println("(1) NUMERO DE CONTROL");
	   		      System.out.println("(2) CURP");
	   		      System.out.println("(3) PRIMER APELLIDO");
	              int b=in.nextInt();
	              
	              switch(b){
	              
	              case 1: 
	            	     m.BuscarNumeroControl(); 
	            	     break;
	            	     
	              case 2: 
	            	     m.BuscarCurp(); 
	            	     break;
	            	     
	              case 3: 
	            	     m.BuscarapellidoPaterno(); 
	            	     break;
	              }
	              
	              break;
	              
	       case 4:
	        	  m.ModificarDatos();	
	        	  break;
	        	  
	       case 5:
	    	      m.EliminarNumeroControl();
	    	      break;
	    	      
	       case 6:
	    	      m.DestruirArchivo();
	    	      break;
	       case 7: System.out.println("Fin");
	       break;
	       default:
	    	       System.out.println("_______________________________");
		           System.out.println("OPCION NO EXISTENTE");
		           System.out.println("_______________________________");
		           break;
	       }
	       
	 	} while (n!=7);
		
    }	
}
