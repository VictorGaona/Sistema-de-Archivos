package archivo;
import  java.io.*;
import  javax.swing.JOptionPane;
import  java.util.*;


public class Metodos{
		 
	   String ruta="C:/Users/Victor Ivan/Desktop/Proyecto/POOFINALAHORASI/ITM.dat";
	   
	   Scanner in=new Scanner(System.in);
	 	
	   public void registrar(){
		   
		      FileOutputStream file=null;
		      DataOutputStream exit=null;
		      
		      int n=0;
		      boolean rep=false;
		      
		      try{
			   
		    	  System.out.println("_______________________________");
			      System.out.println("CANTIDAD DE ALUMNOS A INGRESAR:");
			      n=in.nextInt();     
			      
			      String [] [] arreglo=new String [n][7];
			      
			      file=new FileOutputStream(ruta,true);	
			      exit=new DataOutputStream(file);
			    
			      for(int p=0;	p<n;	p++){	
			    	  
			      System.out.println("_______________________________");  
				  System.out.println("NUMERO DE CONTROL:");
				  arreglo[p][0]=in.next();          
				  
				  System.out.println("_______________________________");
				  System.out.println("INGRESAR NOMBRE:");
				  arreglo[p][1]=in.next();
				  
				  System.out.println("_______________________________");
				  System.out.println("INGRESAR APELLIDO PATERNO:");
				  arreglo[p][2]=in.next(); 
				  
				  System.out.println("_______________________________");
				  System.out.println("INGRESAR APELLIDO MATERNO:");
				  arreglo[p][3]=in.next();   
				  
				  System.out.println("_______________________________");
				  System.out.println("INGRESAR CARRERA:");
				  arreglo[p][4]=in.next(); 
				  
				  System.out.println("_______________________________");
				  System.out.println("INGRESAR CURP:");
				  arreglo[p][5]=in.next();
				  
				  System.out.println("_______________________________");
				  System.out.println("INGRESAR SEMESTRE:");
				  arreglo[p][6]=in.next();
				
			              if(rep==true){	
				             for(int ap=0;ap<(arreglo.length)-1;ap++){	
						         if(arreglo[p][0].equals(arreglo[ap][0])||arreglo[p][5].equals(arreglo[ap][5])){
						        	 
						            System.out.println("DATOS REPETIDOS");
						         }else{
							           if((arreglo[p][4].toLowerCase()).equals("sistemas")||
									      (arreglo[p][4].toLowerCase()).equals("mecanica")||
									      (arreglo[p][4].toLowerCase()).equals("mecatronica")||
									      (arreglo[p][4].toLowerCase()).equals("industrial")||
									      (arreglo[p][4].toLowerCase()).equals("electrica")||
									      (arreglo[p][4].toLowerCase()).equals("electronica")){
								
								          exit.writeUTF(arreglo[p][0]);
								          exit.writeUTF(arreglo[p][1]);
								          exit.writeUTF(arreglo[p][2]);
								          exit.writeUTF(arreglo[p][3]);
								          exit.writeUTF(arreglo[p][4]);
							        	  exit.writeUTF(arreglo[p][5]);
								          exit.writeUTF(arreglo[p][6]);
								
							           }else{
								
							        	  System.out.println("CARRERA SIN VALIDEZ");
								          p--;
							           }
						         }						
					         }
					     }else{	
				
					        if((arreglo[p][4].toLowerCase()).equals("sistemas")||
							   (arreglo[p][4].toLowerCase()).equals("mecanica")||
							   (arreglo[p][4].toLowerCase()).equals("mecatronica")||
							   (arreglo[p][4].toLowerCase()).equals("industrial")||
							   (arreglo[p][4].toLowerCase()).equals("electrica")||
							   (arreglo[p][4].toLowerCase()).equals("electronica")){
						
						       exit.writeUTF(arreglo[p][0]);
						       exit.writeUTF(arreglo[p][1]);
						       exit.writeUTF(arreglo[p][2]);
						       exit.writeUTF(arreglo[p][3]);
						       exit.writeUTF(arreglo[p][4]);
						       exit.writeUTF(arreglo[p][5]);
						       exit.writeUTF(arreglo[p][6]);
						       rep=true;
					}else{
						System.out.println("CARRERA SIN VALIDEZ");
						p--;
					}

			}
			}		
		}catch(NumberFormatException nfe){
			System.out.println(nfe.getMessage());
		}catch(FileNotFoundException fnf){
			System.out.println(fnf.getMessage());
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
			if(exit!=null)exit.close();	
			if(file!=null)file.close();	
			}catch(Exception e){
				System.out.println("iNCORRECTAMENTE CERRADO,  ARCHIVO NO EXISTENTE");
			}
			}
		
	}
	
	

	public void consulta(){
		FileInputStream file=null; //LEER LO QUE ESTA DENTRO DEL ARCHIVO
		DataInputStream exit=null; //CONVERTIDOS, TRANSCRIBE
		String n;
		try{
			file=new FileInputStream(ruta);
			exit=new DataInputStream(file);
			
			while(true){
				n=exit.readUTF();  //lee
				System.out.println(n);
			}
		}catch(EOFException e){
			
		}catch(FileNotFoundException FNF){
			System.out.println("ARCHIVO NO ENCONTRADO"+FNF.getMessage()+".");
		}catch(IOException IOE){
			System.out.println("Error de entrada/salida: "+IOE.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(exit!=null)exit.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada salida:\n"+IOE.getMessage());
			}
		}
	}
	
	public void BuscarNumeroControl(){
		String arreglo[][]=new String [50][7];
		int pos=0;
		String numcontrol;
		FileInputStream file=null;
		DataInputStream exit=null;
		
		try{
			file=new FileInputStream(ruta);
			exit=new DataInputStream(file);
			
			do{
				arreglo[pos][0]=exit.readUTF();
				arreglo[pos][1]=exit.readUTF();
				arreglo[pos][2]=exit.readUTF();
				arreglo[pos][3]=exit.readUTF();
				arreglo[pos][4]=exit.readUTF();
				arreglo[pos][5]=exit.readUTF();
				arreglo[pos][6]=exit.readUTF();
				//lee
				pos++;
			}while(true);
		}catch(EOFException e){
		}catch(FileNotFoundException FNF){
			System.out.println("Archivo no encontrado: "+FNF.getMessage()+".");
		}catch(IOException IOE){
			System.out.println("Error de entrada salida: "+IOE.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(exit!=null)exit.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada salida:\n"+IOE.getMessage());
			}
		}
		
		if(pos==0){
			System.out.println("No se encuentran registros");
		}else{
			System.out.println("Numero de control a buscar");
			numcontrol=in.next();
			for(int k=0;	k<pos;	k++){
				if(numcontrol.equals(arreglo[k][0])){
					System.out.println("Numero de control: " +arreglo[k][0] +"\nNombre: " +arreglo[k][1]
							+"\nApellido Paterno: " +arreglo[k][2] +"\nApellido Materno: " +arreglo[k][3] +"\nCarrera: " 
							+arreglo[k][4] +"\nCURP: " +arreglo[k][5] +"\nSemestre: " +arreglo[k][6]);
				}
			}
		}
		
		
		
	}//metodo

	
	public void BuscarCurp(){
		String arreglo[][]=new String [50][7];
		int pos=0;
		String curp;
		FileInputStream file=null;
		DataInputStream exit=null;
		
		try{
			file=new FileInputStream(ruta);
			exit=new DataInputStream(file);
			do{
				arreglo[pos][0]=exit.readUTF();
				arreglo[pos][1]=exit.readUTF();
				arreglo[pos][2]=exit.readUTF();
				arreglo[pos][3]=exit.readUTF();
				arreglo[pos][4]=exit.readUTF();
				arreglo[pos][5]=exit.readUTF();
				arreglo[pos][6]=exit.readUTF();
				pos++;
			}while(true);
		}catch(EOFException e){
		}catch(FileNotFoundException FNF){
			System.out.println("Archivo no encontrado: "+FNF.getMessage()+".");
		}catch(IOException IOE){
			System.out.println("Error de entrada/salida: "+IOE.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(exit!=null)exit.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada salida:\n"+IOE.getMessage());
			}
			
		}
		
		if(pos==0){
			System.out.println("No se encuentran datos para buscar");
		}else{
			System.out.println("Curp a buscar");
			curp=in.next();
			for(int k=0;	k<pos;	k++){
				if(curp.equals(arreglo[k][5])){
					System.out.println("Numero de control: " +arreglo[k][0] +"\nNombre: " +arreglo[k][1]
							+"\nApellido Paterno: " +arreglo[k][2] +"\nApellido Materno: " +arreglo[k][3] +"\nCarrera: " 
							+arreglo[k][4] +"\nCURP: " +arreglo[k][5] +"\nSemestre: " +arreglo[k][6]);
				}
			}
		}
		
		
		
	}
	
	
	
	public void BuscarapellidoPaterno(){
		FileInputStream file=null;
		DataInputStream exit=null;
		String arreglo[][]=new String [50][7];
		int pos=0;
		String apPat;
		try{
			file=new FileInputStream(ruta);
			exit=new DataInputStream(file);
			
			do{
				arreglo[pos][0]=exit.readUTF();
				arreglo[pos][1]=exit.readUTF();
				arreglo[pos][2]=exit.readUTF();
				arreglo[pos][3]=exit.readUTF();
				arreglo[pos][4]=exit.readUTF();
				arreglo[pos][5]=exit.readUTF();
				arreglo[pos][6]=exit.readUTF();
				pos++;
			}while(true);
		}catch(EOFException e){
		}catch(FileNotFoundException FNF){
			System.out.println("Archivo no encontrado: "+FNF.getMessage()+".");
		}catch(IOException IOE){
			System.out.println("Error de entrada salida: "+IOE.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(exit!=null)exit.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada/salida:\n"+IOE.getMessage());
			}
			
		}
		
		if(pos==0){
			System.out.println("No se encuentran datos");
		}else{
			System.out.println("Buscar apellido paterno");
			apPat=in.next();
			for(int k=0;	k<pos;	k++){
				if(apPat.equals(arreglo[k][2])){	
					System.out.println("Numero de control: " +arreglo[k][0] +"\nNombre: " +arreglo[k][1]
							+"\nApellido Paterno: " +arreglo[k][2] +"\nApellido Materno: " +arreglo[k][3] +"\nCarrera: " 
							+arreglo[k][4] +"\nCURP: " +arreglo[k][5] +"\nSemestre: " +arreglo[k][6]);
				}
			}
		}	
	}
	
	public void ModificarDatos(){
		String arreglo[][]=new String [50][7];
		int pos=0;
		String numcontrol;
		FileInputStream file=null;
		DataInputStream exit=null;
		
		try{
			file=new FileInputStream(ruta);
			exit=new DataInputStream(file);
			
			do{
				arreglo[pos][0]=exit.readUTF();
				arreglo[pos][1]=exit.readUTF();
				arreglo[pos][2]=exit.readUTF();
				arreglo[pos][3]=exit.readUTF();
				arreglo[pos][4]=exit.readUTF();
				arreglo[pos][5]=exit.readUTF();
				arreglo[pos][6]=exit.readUTF();
				pos++;
			}while(true);
		}catch(EOFException e){
		}catch(FileNotFoundException FNF){
			System.out.println("Archivo no encontrado: "+FNF.getMessage()+".");
		}catch(IOException IOE){
			System.out.println("Error de entrada salida: "+IOE.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(exit!=null)exit.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada salida:\n"+IOE.getMessage());
			}
			
		}
		
		if(pos==0){
			System.out.println("No se encuentran registros");
		}else{
			System.out.println("Escribe No.control para cambiar datos");
			numcontrol=in.next();
			for(int k=0;	k<pos;	k++){
				if(numcontrol.equals(arreglo[k][0])){
					
					FileOutputStream salida=null;
					DataOutputStream salida2=null;
					
					try{
						salida=new FileOutputStream(ruta);
						salida2=new DataOutputStream(salida);
						System.out.println("Escriba nuevo dato de carrera");	
						arreglo[k][4]=in.next();
						System.out.println("Escriba nuevo dato de semestre");
							arreglo[k][6]=in.next();
						if((arreglo[k][4].toLowerCase()).equals("sistemas")||
								(arreglo[k][4].toLowerCase()).equals("mecanica")||
								(arreglo[k][4].toLowerCase()).equals("mecatronica")||
								(arreglo[k][4].toLowerCase()).equals("industrial")||
								(arreglo[k][4].toLowerCase()).equals("electrica")||
								(arreglo[k][4].toLowerCase()).equals("electronica")){
							
							salida2.writeUTF(arreglo[k][0]);
							salida2.writeUTF(arreglo[k][1]);
							salida2.writeUTF(arreglo[k][2]);
							salida2.writeUTF(arreglo[k][3]);	
							salida2.writeUTF(arreglo[k][4]);
							salida2.writeUTF(arreglo[k][5]);							
							salida2.writeUTF(arreglo[k][6]);
							
						}else{
							System.out.println("Carrera No Valida");
							k--;
						}					
						
					}catch(NumberFormatException nfe){
						System.out.println(nfe.getMessage());
					}catch(FileNotFoundException fnf){
						System.out.println(fnf.getMessage());
					}catch(IOException ioe){
						System.out.println(ioe.getMessage());
					}finally{
						try{
						if(salida2!=null)salida2.close();
						if(salida!=null)salida.close();
						}catch(Exception e){
							System.out.println("Excepcion Generica");
						}
						}
				}
			}
		}
		
	}
	
	
	public void EliminarNumeroControl(){					
		FileInputStream file=null;
		DataInputStream entrada=null;
		String arreglo[][]=new String [50][7];
		int pos=0;
		String numcontrol;
		try{
			file=new FileInputStream(ruta);
			entrada=new DataInputStream(file);
			
			do{
				arreglo[pos][0]=entrada.readUTF();
				arreglo[pos][1]=entrada.readUTF();
				arreglo[pos][2]=entrada.readUTF();
				arreglo[pos][3]=entrada.readUTF();
				arreglo[pos][4]=entrada.readUTF();
				arreglo[pos][5]=entrada.readUTF();
				arreglo[pos][6]=entrada.readUTF();
				pos++;
			}while(true);
		}catch(EOFException e){
		}catch(FileNotFoundException FNF){
			System.out.println("Archivo no encontrado: "+FNF.getMessage()+".");
		}catch(IOException IOE){
			System.out.println("Error de entrada salida: "+IOE.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(entrada!=null)entrada.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada salida:\n"+IOE.getMessage());
			}
		}
		
		if(pos==0){
			System.out.println("No se encontraron datos");
		}else{
			System.out.println("Introduzca el numero de control");
			numcontrol=in.next();
			for(int k=0;	k<pos;	k++){
				
					
					FileOutputStream salida=null;
					DataOutputStream salida2=null;
					
					try{
						if(numcontrol.equals(arreglo[k][0])){
						salida=new FileOutputStream(ruta);
						salida2=new DataOutputStream(salida);
						if(arreglo[k][0]!=null){
							arreglo[k][0]=arreglo[k+1][0];
							arreglo[k][1]=arreglo[k+1][1];
							arreglo[k][2]=arreglo[k+1][2];
							arreglo[k][3]=arreglo[k+1][3];
							arreglo[k][4]=arreglo[k+1][4];
							arreglo[k][5]=arreglo[k+1][5];
							arreglo[k][6]=arreglo[k+1][6];
						}
						for (int p = 0; p<arreglo.length; p++) {
							salida2.writeUTF(arreglo[p][0]);
							salida2.writeUTF(arreglo[p][1]);
							salida2.writeUTF(arreglo[p][2]);
							salida2.writeUTF(arreglo[p][3]);	
							salida2.writeUTF(arreglo[p][4]);
							salida2.writeUTF(arreglo[p][5]);							
							salida2.writeUTF(arreglo[p][6]);
						}
			}					
				
				}catch(NumberFormatException nfe){
					System.out.println(nfe.getMessage());
				}catch(FileNotFoundException fnf){
					System.out.println(fnf.getMessage());
				}catch(IOException ioe){
					System.out.println(ioe.getMessage());
				}catch (NullPointerException NPE){
					System.out.println("Borrado con exito");
				}finally{
					try{
					if(salida2!=null)salida2.close();
					if(salida!=null)salida.close();
					}catch(Exception e){
						System.out.println("Excepcion Generica");
					}
					}
		
		
		
			}
		}
		
		
		
		
		
	}//metodo
	
	
	
	
	public void DestruirArchivo() {		
		FileOutputStream file=null;
		DataOutputStream exit=null;
		try{
			file=new FileOutputStream(ruta);
			exit=new DataOutputStream(file);
		}catch(FileNotFoundException FNF){
			System.out.println("Archivo no encontrado: "+FNF.getMessage()+".");
		}finally{
			try{
				if(file!=null)file.close();
				if(exit!=null)exit.close();
			}catch(IOException IOE){
				System.out.println("Error de entrada salida:\n"+IOE.getMessage());
			}
		}
		
	}
	
	
	

	

}
